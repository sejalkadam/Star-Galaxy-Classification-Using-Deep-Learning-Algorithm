import numpy as np
import cv2
from keras.layers import Conv2D, MaxPooling2D
from keras.layers import Dropout, Flatten, Dense
from keras.models import Sequential
from keras.layers import Activation
import tensorflow as tf

img_width, img_height = 224, 224

input_shape = (img_width, img_height, 3) 
model = Sequential() 
model.add(Conv2D(256, (2, 2), input_shape = input_shape)) 
model.add(Activation('relu')) 
model.add(MaxPooling2D(pool_size =(2, 2))) 

model.add(Conv2D(128, (2, 2))) 
model.add(Activation('relu')) 
model.add(MaxPooling2D(pool_size =(2, 2))) 

model.add(Conv2D(64, (2, 2))) 
model.add(Activation('relu')) 
model.add(MaxPooling2D(pool_size =(2, 2))) 

model.add(Flatten()) 
model.add(Dense(32)) 
model.add(Activation('relu')) 
model.add(Dropout(0.2)) 
model.add(Dense(2, activation='softmax'))
model.summary()

model.compile(loss ='categorical_crossentropy', 
              optimizer=tf.keras.optimizers.RMSprop(learning_rate=1e-3), 
              metrics =['accuracy']) 

model.load_weights('cnnmodel_saved.h5')
print("done loading weights of trained model")

labels = ['galaxy','star']

# input image
img2 = cv2.imread('galaxy_4012.png')

##====================Classification================================
img1 = cv2.resize(img2, (224, 224))
img1=img1/255
img = np.reshape(img1, [1, 224, 224, 3])

# predict
classes = model.predict(img)
print(classes)
output = np.argmax(classes)
print(np.argmax(classes))
print(labels[output])

font = cv2.FONT_HERSHEY_SIMPLEX
cv2.putText(img2, labels[output], (50,60), font, 2, (255, 255, 255), 5, cv2.LINE_AA)
cv2.imshow('output',img2)
cv2.imwrite('output.jpg',img2)

cv2.waitKey(0)
cv2.destroyAllWindows()