import numpy as np
import json
import cv2
import keras

#load trained models
jsonFileName='detect_vgg.json'
model=keras.models.model_from_json(json.load(open(jsonFileName,'r')))
model.load_weights('model_vgg.hdf5')
print("done loading weights of trained model")

# Labels list
labels = ['Galaxy','Star']

# input image
img = cv2.imread('star_4074.png')
img1 = cv2.resize(img, (256, 256))
cv2.imshow('input', img)  # cropped image
cropped = cv2.resize(img,(200,200))
cropped= cropped/255
cropped = np.reshape(cropped,[1,200,200,3])

# predict
classes = model.predict(cropped)
print(classes)
output = np.argmax(classes)
print(np.argmax(classes))
print(labels[output])

font = cv2.FONT_HERSHEY_SIMPLEX
cv2.putText(img1, labels[output], (30,30), font, 1, (0, 0, 255), 2, cv2.LINE_AA)
cv2.imwrite('outputg3.jpg',img1)
cv2.imshow('output',img1)

cv2.waitKey(0)
cv2.destroyAllWindows()
